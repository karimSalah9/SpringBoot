package task.ssm.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.statemachine.StateMachine;
import org.springframework.statemachine.config.StateMachineFactory;

import task.ssm.domain.EmployeeEvents;
import task.ssm.domain.EmployeeStates;

@SpringBootTest
class Test {

	@Autowired
	StateMachineFactory<EmployeeStates, EmployeeEvents> factory;

	@org.junit.jupiter.api.Test
	void test() {
		StateMachine<EmployeeStates, EmployeeEvents> sm = factory.getStateMachine(UUID.randomUUID());

		sm.start();
		System.out.println(sm.getState().toString());
		sm.sendEvent(EmployeeEvents.ADD);
		System.out.println(sm.getState().toString());
		sm.sendEvent(EmployeeEvents.IN_CHECK);
		System.out.println(sm.getState().toString());
		sm.sendEvent(EmployeeEvents.ERROR);
		System.out.println(sm.getState().toString());
//		sm.sendEvent(EmployeeEvents.ACTIVATE);
//		System.out.println(sm.getState().toString());
		
		
		
		
		
	}

}
