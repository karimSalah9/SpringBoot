package task.ssm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import task.ssm.domain.Employee;

public interface EmployeeRepo extends JpaRepository<Employee,Integer> {

}
