package task.ssm.domain;

public enum EmployeeStates {
ADDED,IN_CHECK,APPROVED,ACTIVE,ERROR
}
