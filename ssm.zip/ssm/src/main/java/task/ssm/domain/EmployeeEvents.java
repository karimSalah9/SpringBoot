package task.ssm.domain;

public enum EmployeeEvents {
ADD,IN_CHECK,APPROVAL,ACTIVATE,ERROR
}
