package task.ssm.config;

import java.util.EnumSet;

import org.springframework.context.annotation.Configuration;
import org.springframework.statemachine.config.EnableStateMachineFactory;
import org.springframework.statemachine.config.StateMachineConfigurerAdapter;
import org.springframework.statemachine.config.builders.StateMachineConfigurationConfigurer;
import org.springframework.statemachine.config.builders.StateMachineStateConfigurer;
import org.springframework.statemachine.config.builders.StateMachineTransitionConfigurer;
import org.springframework.statemachine.listener.StateMachineListenerAdapter;
import org.springframework.statemachine.state.State;

import lombok.extern.slf4j.Slf4j;
import task.ssm.domain.EmployeeEvents;
import task.ssm.domain.EmployeeStates;

@Slf4j
@Configuration
@EnableStateMachineFactory

public class StateMachineConfig extends StateMachineConfigurerAdapter<EmployeeStates, EmployeeEvents> {

	@Override
	public void configure(StateMachineStateConfigurer<EmployeeStates, EmployeeEvents> states) throws Exception {
		states.withStates().initial(EmployeeStates.ADDED).states(EnumSet.allOf(EmployeeStates.class))
				.end(EmployeeStates.ACTIVE).end(EmployeeStates.ERROR);
	}

	@Override
	public void configure(StateMachineTransitionConfigurer<EmployeeStates, EmployeeEvents> transitions)
			throws Exception {

		transitions.withExternal().source(EmployeeStates.ADDED).target(EmployeeStates.ADDED).event(EmployeeEvents.ADD)
				.and().withExternal().source(EmployeeStates.ADDED).target(EmployeeStates.IN_CHECK)
				.event(EmployeeEvents.IN_CHECK).and().withExternal().source(EmployeeStates.IN_CHECK)
				.target(EmployeeStates.APPROVED).event(EmployeeEvents.APPROVAL).and().withExternal()
				.source(EmployeeStates.IN_CHECK).target(EmployeeStates.ERROR).event(EmployeeEvents.ERROR).and()
				.withExternal().source(EmployeeStates.APPROVED).target(EmployeeStates.ACTIVE)
				.event(EmployeeEvents.ACTIVATE);

	}

	@Override
	public void configure(StateMachineConfigurationConfigurer<EmployeeStates, EmployeeEvents> config) throws Exception {
		StateMachineListenerAdapter<EmployeeStates, EmployeeEvents> adapter = new StateMachineListenerAdapter<EmployeeStates, EmployeeEvents>() {

			@Override
			public void stateChanged(State<EmployeeStates, EmployeeEvents> from,
					State<EmployeeStates, EmployeeEvents> to) {
				// TODO Auto-generated method stub
				super.stateChanged(from, to);
				System.out.println("the state goes from: " + from + "   then goes to :" + to);
			}
		};
		config.withConfiguration().listener(adapter);
	}

}
