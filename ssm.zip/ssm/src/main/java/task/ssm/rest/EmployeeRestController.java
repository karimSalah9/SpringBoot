package task.ssm.rest;

import java.util.List;
import java.util.UUID;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.statemachine.StateMachine;
import org.springframework.statemachine.config.StateMachineFactory;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import task.ssm.domain.Employee;
import task.ssm.domain.EmployeeEvents;
import task.ssm.domain.EmployeeStates;
import task.ssm.services.EmplyeeService;

@RestController
@RequestMapping("/api")
public class EmployeeRestController {
	@Autowired
	private EmplyeeService service;

	@Autowired
	StateMachineFactory<EmployeeStates, EmployeeEvents> factory;

	StateMachine<EmployeeStates, EmployeeEvents> sm;

	public EmployeeRestController(EmplyeeService service, StateMachineFactory<EmployeeStates, EmployeeEvents> factory) {
		this.service = service;
		this.factory = factory;
		this.sm = factory.getStateMachine(UUID.randomUUID());

	}

	@GetMapping("/employees")
	public List<Employee> findAll() {

		return service.findAll();
	}

	@GetMapping("/employee/{id}")
	public Employee findById(@PathVariable int id) {
		return service.findById(id);
	}

	@PostMapping("/employee")
	public Employee addEmployee(@RequestBody Employee employee) {

		sm.start();
		System.out.println(sm.getState().toString());
		sm.sendEvent(EmployeeEvents.ADD);
		System.out.println("Key --------------" + sm.getState().getId());
		System.out.println("koko --" + sm.getState().getId().name());

		employee.setState(sm.getState().getId().name());
		return service.addEmployee(employee);
	}

	@PutMapping("/employee")
	public Employee updateEmployee(@RequestBody Employee employee) {

		return service.addEmployee(employee);
	}

	@PostMapping("/employee/state/{id}")
	public Employee updateEmployeeState(@PathVariable int id) {
		Employee employee = service.findById(id);
		sm.start();
		System.out.println(sm.getState().toString());
		sm.sendEvent(EmployeeEvents.IN_CHECK);
		System.out.println("Key --------------" + sm.getState().getId());
		System.out.println("koko --" + sm.getState().getId().name());

		employee.setState(sm.getState().getId().name());

		return service.addEmployee(employee);
	}

	@DeleteMapping("/employee/{id}")
	public void deleteById(@PathVariable int id) {
		service.deleteById(id);

	}
}
