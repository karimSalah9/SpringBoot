package task.ssm.services;

import java.util.List;

import task.ssm.domain.Employee;

public interface EmplyeeService {
	
	
	public List<Employee> findAll();

	public Employee findById(int id);

	public Employee addEmployee(Employee employee);

	public void deleteById(int id);

	public Employee updateEmployee(Employee employee);

}
