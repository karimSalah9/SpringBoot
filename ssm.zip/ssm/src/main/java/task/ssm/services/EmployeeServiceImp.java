package task.ssm.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import task.ssm.domain.Employee;
import task.ssm.repository.EmployeeRepo;

@Service
public class EmployeeServiceImp implements EmplyeeService {
	private EmployeeRepo repo;

	@Autowired
	public EmployeeServiceImp(EmployeeRepo repo) {
		super();
		this.repo = repo;
	}

	@Override
	public List<Employee> findAll() {
		return repo.findAll();
	}

	@Override
	public Employee findById(int id) {
		Optional<Employee> emp = repo.findById(id);
		return emp.get();
	}

	@Override
	public Employee addEmployee(Employee employee) {
		// employee.setState(null);
		return repo.save(employee);
	}

	@Override
	public void deleteById(int id) {
		repo.deleteById(id);
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		return repo.save(employee);
	}

}
