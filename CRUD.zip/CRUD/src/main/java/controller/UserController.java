package controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import repository.UserRepository;

//make this class as rest controller 

@RestController
@RequestMapping(value = "/user")
public class UserController {
	@Autowired
	UserRepository ur;

	@RequestMapping("/t")
	public  String check() {
		return ("Welcome To My First App!");
	}
	@GetMapping(value="/getuser")
	public List<String> GetAllUserName() {
		return ur.GetAllNames();
	}

}
