package repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
@Repository
public class UserRepository {

	@Autowired
	JdbcTemplate jt;

	public List<String> GetAllNames() {
		List<String> users = new ArrayList<>();
		users.addAll(jt.queryForList("select user_name from user ;", String.class));
		return users;
	}

}
